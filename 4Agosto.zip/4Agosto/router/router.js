
import  express  from "express";
import Controller from "../controllers/controller.js";
import axios from "axios"

const router = express.Router()




//point Home
router.get('/home', Controller.homepage)

// Apertura della pagina di modifica tweet
router.get('/edit/:id',Controller.getTweet)
//controllo aggiunta
router.post('/api/tweet', Controller.addTweet)
//modifica
// Apertura della pagina di modifica tweet
router.patch('/api/tweet/:id', Controller. editTweet);
 
// Mostra il form per l'inserimento di un nuovo tweet
router.get('/api/tweet/new', Controller.formPage)

//search
router.get('/api/tweets', Controller.searchTweets);

export default router