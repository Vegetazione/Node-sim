import axios from "axios";

const menuItems = [
  { path: "/home", label: "Home" },
  { path: "/api/tweet/new", label: "Add" },

];

const jsonURL = "http://localhost:3000/tweets";

class Controller {
  //controllo Home
  static async homepage(req, res) {
    const response = await axios.get(`${jsonURL}`);
    res.render("pages/home", { menuItems: menuItems, tweets: response.data });
  }
  //controllo Form
  static async formPage(req, res) {
    const response = await axios.get(`${jsonURL}`);
    res.render("pages/tweet-form", {
      menuItems: menuItems,
      tweets: response.data,
    });
  }
  //aggiunta tweet
  static async addTweet(req, res) {
    const { text } = req.body;
    const date = new Date().toLocaleString();
    const response = await axios.post(`${jsonURL}`, { text, date });
    res.redirect("/home");
  }
//get
  static async getTweet(req, res) {
    const id = req.params.id;
    try {
      const response = await axios.get(`http://localhost:3000/tweets/${id}`);

      res.render("pages/edit", { menuItems: menuItems, tweets: response.data });
    } catch (error) {
      console.error(
        "Si è verificato un errore durante il recupero del tweet.",
        error
      );
      res.redirect("/");
    }
  }
//edit
  static async editTweet(req, res) {
    const { id } = req.params;
    const { text } = req.body;
    try {
      // Effettua la richiesta PATCH utilizzando Axios
      await axios.patch(`${jsonURL}/${id}`, { text });
      // Invia una risposta di successo
      res.send("Tweet aggiornato con successo!");
    } catch (error) {
      console.error(
        "Si è verificato un errore durante l'aggiornamento del tweet.",
        error
      );
      // Invia una risposta di errore
      res
        .status(500)
        .send("Si è verificato un errore durante l'aggiornamento del tweet.");
    }
  }
  //search
  static async searchTweets(req, res) {
    const searchValue = req.query.search;
    if (!searchValue) {
      return res
        .status(400)
        .json({ error: "Il parametro di ricerca è mancante." });
    }
    // Effettua una richiesta per ottenere tutti i tweet dal server tramite Axios
    const response = await axios.get(jsonURL);
    const tweets = response.data;
    // Filtra i tweet che contengono la sottostringa cercata
    const filteredTweets = tweets.filter((tweet) =>
      tweet.text.includes(searchValue)
    );
    res.json(filteredTweets);
  }
  //???non funziona
  static async replaceHashtagsWithLinks(text) {
    const regex = /#(\w+)/g;
    const replaceFunc = (match, hashtag) => {
      return `<a href="/api/tweet?hashtag=${hashtag}">${match}</a>`;
    };
    return text.replace(regex, replaceFunc);
  }
}

export default Controller;
